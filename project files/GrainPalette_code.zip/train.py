
"""GrainPalette - Training script for Rice Type Classification using Transfer Learning

Usage:
    python train.py --data_dir /path/to/dataset --model efficientnet --batch_size 32 --epochs 20 --img_size 224 --output_dir ./output
Dataset structure expected:
    dataset/
        train/
            class1/
            class2/
            ...
        val/
            class1/
            class2/
            ...
        test/   (optional)
            class1/
            class2/
            ...
"""
import argparse
import os
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks, optimizers
import numpy as np

def get_datasets(data_dir, img_size=224, batch_size=32, seed=123):
    train_dir = os.path.join(data_dir, 'train')
    val_dir = os.path.join(data_dir, 'val')
    test_dir = os.path.join(data_dir, 'test')

    train_ds = tf.keras.preprocessing.image_dataset_from_directory(
        train_dir,
        image_size=(img_size, img_size),
        batch_size=batch_size,
        label_mode='categorical',
        shuffle=True,
        seed=seed
    )
    val_ds = tf.keras.preprocessing.image_dataset_from_directory(
        val_dir,
        image_size=(img_size, img_size),
        batch_size=batch_size,
        label_mode='categorical',
        shuffle=False,
        seed=seed
    )
    test_ds = None
    if os.path.exists(test_dir):
        test_ds = tf.keras.preprocessing.image_dataset_from_directory(
            test_dir,
            image_size=(img_size, img_size),
            batch_size=batch_size,
            label_mode='categorical',
            shuffle=False
        )
    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.cache().prefetch(buffer_size=AUTOTUNE)
    val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)
    if test_ds is not None:
        test_ds = test_ds.cache().prefetch(buffer_size=AUTOTUNE)
    return train_ds, val_ds, test_ds

def data_augmentation_layer(img_size=224):
    return tf.keras.Sequential([
        layers.Rescaling(1./255),
        layers.RandomFlip('horizontal'),
        layers.RandomRotation(0.08),
        layers.RandomZoom(0.08),
        layers.RandomContrast(0.08),
    ], name='data_augmentation')

def build_model(num_classes, base_model_name='efficientnet', img_size=224, trainable_layers=20, dropout=0.4):
    input_shape = (img_size, img_size, 3)
    inputs = layers.Input(shape=input_shape)
    aug = data_augmentation_layer(img_size)(inputs)

    # Choose base model
    if base_model_name.lower() == 'resnet50':
        base = tf.keras.applications.ResNet50(include_top=False, weights='imagenet', input_tensor=aug, pooling='avg')
    elif base_model_name.lower() == 'vgg16':
        base = tf.keras.applications.VGG16(include_top=False, weights='imagenet', input_tensor=aug, pooling='avg')
    elif base_model_name.lower() == 'inceptionv3':
        base = tf.keras.applications.InceptionV3(include_top=False, weights='imagenet', input_tensor=aug, pooling='avg')
    elif base_model_name.lower() == 'mobilenetv2':
        base = tf.keras.applications.MobileNetV2(include_top=False, weights='imagenet', input_tensor=aug, pooling='avg')
    else:
        # default efficientnet
        base = tf.keras.applications.EfficientNetB0(include_top=False, weights='imagenet', input_tensor=aug, pooling='avg')

    # Freeze base
    base.trainable = True
    # Optionally fine-tune a subset
    if trainable_layers is not None and trainable_layers >= 0:
        # Freeze all then unfreeze last `trainable_layers` layers
        for layer in base.layers[:-trainable_layers]:
            layer.trainable = False

    x = base.output
    x = layers.Dropout(dropout)(x)
    outputs = layers.Dense(num_classes, activation='softmax')(x)
    model = models.Model(inputs=inputs, outputs=outputs)
    return model

def compile_and_train(model, train_ds, val_ds, output_dir, lr=1e-4, epochs=20):
    model.compile(
        optimizer=optimizers.Adam(learning_rate=lr),
        loss='categorical_crossentropy',
        metrics=['accuracy', tf.keras.metrics.Precision(name='precision'), tf.keras.metrics.Recall(name='recall')]
    )
    os.makedirs(output_dir, exist_ok=True)
    checkpoint_cb = callbacks.ModelCheckpoint(os.path.join(output_dir, 'best_model.h5'), save_best_only=True, monitor='val_accuracy', mode='max')
    early_cb = callbacks.EarlyStopping(monitor='val_accuracy', patience=6, restore_best_weights=True)
    reduce_cb = callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-7)

    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs,
        callbacks=[checkpoint_cb, early_cb, reduce_cb]
    )
    # Save final model
    model.save(os.path.join(output_dir, 'final_model'))
    return history

def evaluate_model(model, test_ds):
    if test_ds is None:
        print('No test dataset provided. Skipping evaluation.')
        return
    results = model.evaluate(test_ds)
    print('Test results:', results)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', required=True, help='Path to dataset root (with train/val/test subfolders)')
    parser.add_argument('--model', default='efficientnet', choices=['resnet50','vgg16','inceptionv3','mobilenetv2','efficientnet'], help='Pretrained base model to use')
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--img_size', type=int, default=224)
    parser.add_argument('--output_dir', type=str, default='./output')
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--trainable_layers', type=int, default=20)
    return parser.parse_args()

def main():
    args = parse_args()
    train_ds, val_ds, test_ds = get_datasets(args.data_dir, img_size=args.img_size, batch_size=args.batch_size)
    # determine number of classes
    for x,y in train_ds.take(1):
        num_classes = y.shape[1]
    model = build_model(num_classes=num_classes, base_model_name=args.model, img_size=args.img_size, trainable_layers=args.trainable_layers)
    model.summary()
    compile_and_train(model, train_ds, val_ds, args.output_dir, lr=args.lr, epochs=args.epochs)
    evaluate_model(model, test_ds)

if __name__ == '__main__':
    main()
