
# GrainPalette - Code Package

## Files
- train.py : Main training script that uses transfer learning.
- utils.py : Small helper functions for inference and preprocessing.
- requirements.txt : Python dependencies.

## Quickstart
1. Prepare dataset with `train/`, `val/`, `test/` subfolders and sub-subfolders per class.
2. Create a virtual environment and install requirements: `pip install -r requirements.txt`
3. Train: `python train.py --data_dir /path/to/dataset --model efficientnet --epochs 20 --batch_size 32 --img_size 224 --output_dir ./output`

## Notes
- The script expects an ImageNet-like preprocessing (images scaled to [0,1]).
- For small datasets, use lower learning rate and more aggressive data augmentation.
- Consider using TensorFlow Dataset and tf.data optimizations for very large datasets.
