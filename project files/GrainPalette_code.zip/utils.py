
"""Utility functions for GrainPalette project"""
import tensorflow as tf
import numpy as np

def load_model(path):
    return tf.keras.models.load_model(path)

def preprocess_image(image_path, img_size=224):
    img = tf.keras.preprocessing.image.load_img(image_path, target_size=(img_size, img_size))
    arr = tf.keras.preprocessing.image.img_to_array(img)
    arr = arr / 255.0
    arr = np.expand_dims(arr, axis=0)
    return arr

def predict(model, image_array, class_names):
    preds = model.predict(image_array)
    idx = preds.argmax(axis=1)[0]
    return class_names[idx], float(preds[0][idx])
